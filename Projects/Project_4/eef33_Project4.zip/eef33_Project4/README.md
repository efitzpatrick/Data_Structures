To run this program, run as said before:
java reporting2 input.txt


Output: 
eef33HS.txt
eef33QS.txt
eef33MS.txt


