3/23/17
Project created by Ellie Fitzpatrick for EECS 233.
To run: 
java HuffmanCompressor [input.txt] [output.txt]
Example:
java HuffmanCompressor modest_proposal.txt mp_output.txt