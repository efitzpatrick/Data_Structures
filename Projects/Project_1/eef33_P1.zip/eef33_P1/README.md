#Project 1: Phonebook Creator#
### By: Ellie Fitzpatrick (eef33)###
### 19 February, 2017###


## Running the Program###
1. Open up the folders in your desired compiler
2. Navigate to Phonebook.java
3. Run PhoneBook.java

